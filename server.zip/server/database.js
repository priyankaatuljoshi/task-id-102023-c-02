

//const{Pool}=require("pg")
const { Pool } = require("pg");

const pool = new Pool({
    user: "postgres",
    password: "root",
    host:"localhost",
    port: 5432,
    database:"user_registration"
}) 

const createtbl =`create table userform(
    user_id serial Primary key,
    username varchar(50) unique not null,
    password varchar(50) unique not null ,
       email varchar(50) unique not null );`




 //pool.query("create database user_registration;")
pool.query(createtbl)
.then((Response)=>{
console.log("table created")
    console.log(Response)
})
.catch((err)=>{
console.log(err);

});
module.exports=pool;
