const express=require("express")
const cors=require("cors")
const pool = require("./database")
const app=express()
app.use(express.json())
app.use(cors())

// app.get("/adduser",(req,resp)=>{
//     console.log(req.body)
//     resp.send("Response received:"+req.body);
// });

app.post("/adduser",(req,resp)=>{
    const username=req.body["username"]
    const password=req.body["password"]
    const email=req.body["email"]


    console.log("username:"+username)
    console.log("password:"+password)
    console.log("email:"+email)


    const insertdata= `insert into userform(username,password,email) values('${username}','${password}','${email}');`
    pool.query(insertdata).then((response)=>{
        console.log(("data saved"))
    })
    .catch((err)=>{

        console.log(err);
    });
    console.log(req.body)
       resp.send("Response received:"+req.body);
    
})

app.listen(4000, ()=>console.log("server on localhost : 4000"));