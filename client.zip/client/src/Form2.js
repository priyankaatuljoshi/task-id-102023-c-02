import React from 'react';
import { useLocation } from 'react-router-dom';

import { BrowserRouter, Route, Switch } from 'react-router-dom';
import { useEffect, useReducer, useState } from "react";
//import { useNavigate } from "react-router-dom";
//import { Link } from "react-router-dom";
export default function Form2()
{const location = useLocation();
  const { pathname } = location;

     const init={

        username:"",
       password:"",
       email:""
     }
     
     const reducer=(state,action)=>{

        switch(action.type)
        {
            case 'update':
               return {...state,[action.fld]:action.val}
            case 'reset':
                return init;
        }
     }
       const [info,dispatch]=useReducer(reducer,init);
       //const navigate=useNavigate();
       
      
      

       const sendData = (e) => {
        e.preventDefault();
        const reqOptions = {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(info),
        };
        fetch("http://localhost:4000/adduser", reqOptions)
          .then((resp) => {
            resp.json();
            console.log(resp.status);
            if (resp.status === 200) {
            //navigate("/Success")
            } else {
             window.location.reload();
            }
          })
          .catch((e) => {
            console.log(e);
            window.location.reload();
          });
      };

     return(
        <div >
       <form >
        <div>
          <label>Username</label>
          <input type="text" name="username" value={info.username} />
        </div>
        <div>
          <label>Password</label>
          <input type="password" name="password" value={info.password}  />
        </div>
        <div>
          <label>Email</label>
          <input type="email" name="email" value={info.email} />
        </div>
        <button type="submit"  onClick={(e)=>{sendData(e)}}>Submit</button>
      </form>
    </div>
               
               
               
               
              
             
    )
}