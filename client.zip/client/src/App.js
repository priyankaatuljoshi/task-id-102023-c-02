import './App.css';
import React from 'react';

import Form2 from './Form2';
//import { Router } from 'react-router-dom';
import { BrowserRouter as Router } from 'react-router-dom';

const App=()=>{
return (
  <Router>
  <div><h1>User Registration</h1>

<Form2/>
  </div>
  </Router>
)

}

export default App;
